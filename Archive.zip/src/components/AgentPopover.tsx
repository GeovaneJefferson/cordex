import React, { useState, useRef, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { useAgent } from '../hooks/useAgent';

export const AgentPopover: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [goal, setGoal] = useState('');
  const [position, setPosition] = useState({ top: 0, left: 0 });
  const buttonRef = useRef<HTMLButtonElement>(null);
  const { runAgent, stopAgent } = useAgent();
  const [running, setRunning] = useState(false);

  const handleOpen = () => {
    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      setPosition({
        top: rect.bottom + window.scrollY + 4,
        left: rect.left + window.scrollX,
      });
    }
    setIsOpen(true);
  };

  const handleClose = () => {
    setIsOpen(false);
    setGoal('');
  };

  const handleRun = async () => {
    setRunning(true);
    await runAgent(goal);
    setRunning(false);
    handleClose();
  };

  // Portal content
  const popover = isOpen ? ReactDOM.createPortal(
    <div
      style={{
        position: 'absolute',
        top: position.top,
        left: position.left,
        width: 320,
        background: 'white',
        border: '1px solid #e2e8f0',
        borderRadius: 12,
        boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04)',
        zIndex: 9999,
        padding: 12,
      }}
    >
      <textarea
        value={goal}
        onChange={(e) => setGoal(e.target.value)}
        placeholder="What do you want the agent to do?"
        rows={3}
        className="w-full border border-gray-200 rounded-lg p-2 text-sm resize-none focus:outline-none focus:border-orange-400"
      />
      <div className="flex justify-end gap-2 mt-3">
        <button onClick={handleClose} className="px-3 py-1 text-xs text-gray-500 hover:bg-gray-100 rounded">
          Cancel
        </button>
        <button
          onClick={handleRun}
          disabled={running || !goal.trim()}
          className="px-3 py-1 text-xs bg-orange-500 text-white rounded hover:bg-orange-600 disabled:opacity-50"
        >
          {running ? 'Running...' : 'Run Agent'}
        </button>
      </div>
    </div>,
    document.body
  ) : null;

  return (
    <>
      <button
        ref={buttonRef}
        onClick={handleOpen}
        className={`flex items-center gap-1 px-3 py-1 rounded-full text-[11.5px] font-medium transition-all select-none active:scale-95 bg-orange-50 text-orange-600 border border-orange-200 hover:bg-orange-100`}
        title="Run AI Agent"
      >
        <span className="material-symbols-outlined text-[14px]">smart_toy</span>
        Agent
      </button>
      {popover}
    </>
  );
};