import { useEffect, useRef } from 'react';
import { getExtensions } from '../extensions/registry'; // correct path

interface Extension {
  id: string;
  enabled: boolean;
}

export function usePythonLSP(language: string, projectRoot: string | null) {
  const startedRef = useRef(false);

  useEffect(() => {
    if (!projectRoot || language !== 'python') return;

    let extensions: Extension[] = [];
    try {
      extensions = getExtensions();
    } catch (err) {
      console.warn('[usePythonLSP] Failed to load extensions:', err);
      return;
    }

    const pyright = extensions.find((ext: Extension) => ext.id === 'pyright');
    const isEnabled = pyright?.enabled === true;

    if (!isEnabled) {
      if (startedRef.current) {
        (window as any).Cordex?.lsp?.stopPython?.();
        startedRef.current = false;
      }
      return;
    }

    if (startedRef.current) return;
    startedRef.current = true;

    (window as any).Cordex?.lsp?.startPython?.(projectRoot).catch((err: any) => {
      console.error('[usePythonLSP] Failed to start LSP:', err);
      startedRef.current = false;
    });

    return () => {
      if (startedRef.current) {
        (window as any).Cordex?.lsp?.stopPython?.();
        startedRef.current = false;
      }
    };
  }, [language, projectRoot]);
}