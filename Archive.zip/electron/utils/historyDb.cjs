'use strict'
/**
 * historyDb.cjs — Pure-JS JSON file storage for local file history.
 * NO native modules. Crash-proof.
 *
 * Layout: userData/history/<md5(filePath)>.json
 * Each file → JSON array of { id, timestamp, size, content(base64+zlib) }
 */
const path   = require('path')
const fs     = require('fs-extra')
const zlib   = require('zlib')
const crypto = require('crypto')

const MAX_VERSIONS  = 50
const MAX_FILE_SIZE = 500 * 1024
const SKIP_DIRS     = new Set(['node_modules','.git','dist','build','__pycache__','.venv','venv','.next','coverage'])

function historyDir() {
  const { app } = require('electron')
  return path.join(app.getPath('userData'), 'history')
}
function fileKey(fp) { return crypto.createHash('md5').update(fp).digest('hex') }
function histFile(fp) { return path.join(historyDir(), `${fileKey(fp)}.json`) }

function shouldTrack(fp, size) {
  if (size > MAX_FILE_SIZE) return false
  return !fp.replace(/\\/g,'/').split('/').some(p => SKIP_DIRS.has(p))
}

async function saveSnapshot(filePath, content) {
  try {
    const size = Buffer.byteLength(content, 'utf8')
    if (!shouldTrack(filePath, size)) return false
    const hf = histFile(filePath)
    let snaps = []; try { snaps = await fs.readJson(hf) } catch {}
    const compressed = zlib.deflateSync(Buffer.from(content,'utf8')).toString('base64')
    snaps.unshift({ id: Date.now(), timestamp: Date.now(), size, content: compressed })
    if (snaps.length > MAX_VERSIONS) snaps = snaps.slice(0, MAX_VERSIONS)
    await fs.outputJson(hf, snaps)
    return true
  } catch (err) {
    console.warn('[historyDb] saveSnapshot error:', err.message)
    return false
  }
}

async function listSnapshots(filePath) {
  try {
    const snaps = await fs.readJson(histFile(filePath))
    return snaps.map(s => ({ id: s.id, timestamp: s.timestamp, size: s.size }))
  } catch { return [] }
}

async function restoreSnapshot(id, filePath) {
  try {
    const snaps = await fs.readJson(histFile(filePath))
    const snap  = snaps.find(s => s.id === id)
    if (!snap) return null
    return zlib.inflateSync(Buffer.from(snap.content, 'base64')).toString('utf8')
  } catch { return null }
}

async function deleteSnapshot(id, filePath) {
  try {
    const hf = histFile(filePath)
    let snaps = await fs.readJson(hf)
    snaps = snaps.filter(s => s.id !== id)
    await fs.outputJson(hf, snaps)
    return true
  } catch { return false }
}

async function deleteAllForFile(filePath) {
  try { await fs.remove(histFile(filePath)); return true } catch { return false }
}

module.exports = { saveSnapshot, listSnapshots, restoreSnapshot, deleteSnapshot, deleteAllForFile }
