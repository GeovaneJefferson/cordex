// electron/utils/profileManager.cjs
// Loads ai_profiles.json, evaluates hardware traffic-light tiers,
// and provides the resolved profile to the rest of the app.
'use strict'
const path = require('path')
const fs   = require('fs-extra')
const http = require('http')

const PROFILE_PATH = path.join(__dirname, '../../config/ai_profiles.json')

let _profile  = null
let _resolved = null   // profile with hardware-resolved traffic lights

// ── Load raw profile ───────────────────────────────────────────────────────
function loadProfile() {
  if (_profile) return _profile
  try {
    _profile = fs.readJsonSync(PROFILE_PATH)
  } catch {
    _profile = { global_configuration: {}, models: {} }
  }
  return _profile
}

// ── Get available VRAM from Ollama ─────────────────────────────────────────
async function getAvailableVram() {
  return new Promise(resolve => {
    const req = http.get('http://127.0.0.1:11434/api/show', { timeout: 2000 }, res => {
      // Ollama doesn't expose VRAM directly — we use /api/ps for loaded models
      resolve(null)
    })
    req.on('error', () => resolve(null))
    req.setTimeout(2000, () => { req.destroy(); resolve(null) })
  })
}

// ── Get hardware info from the existing hardwareHandler route ─────────────
function getHardwareFromCache() {
  return (global.__cordexHardware) || null
}

// ── Resolve traffic light for a model based on actual hardware ─────────────
// Green  = GPU VRAM >= model footprint + 1.5GB overhead
// Yellow = GPU VRAM insufficient but system RAM is capable
// Red    = total memory insufficient
function resolveTrafficLight(modelEntry, hw) {
  const min = modelEntry.hardware_requirements?.minimum_vram_gb ?? 0
  if (!hw) return 'Green'   // unknown hardware → optimistic

  const hasGpu  = hw.has_gpu && hw.vram_mb > 0
  const vramGb  = (hw.vram_mb ?? 0) / 1024
  const ramGb   = hw.total_ram_gb ?? 0
  const OVERHEAD = 1.5

  if (hasGpu && vramGb >= min + OVERHEAD)  return 'Green'
  if (ramGb  >= min + OVERHEAD)             return 'Yellow'
  return 'Red'
}

// ── Build resolved profile (inject traffic lights from hardware check) ─────
function resolveProfile(hw) {
  const raw = loadProfile()
  const out  = JSON.parse(JSON.stringify(raw))   // deep copy

  for (const key of Object.keys(out.models)) {
    const m     = out.models[key]
    const light = resolveTrafficLight(m, hw)
    m.ui_features = m.ui_features || {}
    m.ui_features.traffic_light_tier = light
    m.ui_features.on_gpu = !!(hw?.has_gpu && hw.vram_mb > 0)
  }

  _resolved = out
  return out
}

// ── Verify baseline models are pulled, pull if missing ────────────────────
async function ensureBaselineModels(win) {
  const raw = loadProfile()
  const needed = [
    raw.global_configuration?.default_autocomplete_model,
    raw.global_configuration?.default_embedding_model,
  ].filter(Boolean)

  // List installed models
  const installed = await new Promise(resolve => {
    const req = http.get('http://127.0.0.1:11434/api/tags', { timeout: 3000 }, res => {
      let body = ''
      res.on('data', d => body += d)
      res.on('end', () => {
        try { resolve(JSON.parse(body).models?.map(m => m.name) ?? []) }
        catch { resolve([]) }
      })
    })
    req.on('error', () => resolve([]))
  })

  for (const model of needed) {
    const present = installed.some(n => n === model || n.startsWith(model.split(':')[0]))
    if (present) continue

    // Pull silently
    if (win && !win.isDestroyed()) {
      win.webContents.send('profile:pulling-baseline', { model })
    }
    await new Promise((resolve, reject) => {
      const body = JSON.stringify({ name: model, stream: true })
      const opts = {
        hostname: '127.0.0.1', port: 11434, path: '/api/pull', method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      }
      const req = http.request(opts, res => {
        res.on('data', chunk => {
          try {
            const j = JSON.parse(chunk.toString().split('\n').filter(Boolean).pop() || '{}')
            if (win && !win.isDestroyed() && j.status) {
              win.webContents.send('profile:pulling-baseline', { model, status: j.status, pct: j.total ? Math.round((j.completed/j.total)*100) : 0 })
            }
          } catch {}
        })
        res.on('end', resolve)
        res.on('error', reject)
      })
      req.on('error', reject)
      req.write(body); req.end()
    }).catch(() => {})
  }
}

// ── Public API ─────────────────────────────────────────────────────────────
module.exports = {
  loadProfile,
  resolveProfile,
  ensureBaselineModels,
  getChatModels() {
    const p = _resolved || loadProfile()
    return Object.values(p.models).filter(m =>
      m.role !== 'codebase_vectorization' && m.role !== 'inline_ghost_text_autocomplete'
    )
  },
  getModelByIdentifier(id) {
    const p = _resolved || loadProfile()
    return Object.values(p.models).find(m => m.model_identifier === id) || null
  },
  getGlobalConfig() {
    return ((_resolved || loadProfile()).global_configuration) || {}
  },
}
