import React, { useState, useRef, useEffect, useCallback } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { useAppState } from '../store/AppContext';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  thinking?: string;        // raw <think> content
  thinkOpen?: boolean;      // whether the think block is expanded
}

const Cordex = (window as any).Cordex;

function flattenFileTree(nodes: any[], prefix = ''): string[] {
  let files: string[] = [];
  for (const node of nodes) {
    const fullPath = prefix ? `${prefix}/${node.name}` : node.name;
    if (node.type === 'file') files.push(fullPath);
    else if (node.children) files = files.concat(flattenFileTree(node.children, fullPath));
  }
  return files;
}

// ── Code block with copy button ───────────────────────────────────────────────
const CodeBlock: React.FC<{ language: string; code: string }> = ({ language, code }) => {
  const [copied, setCopied] = useState(false);
  const handleCopy = async () => {
    try { await navigator.clipboard.writeText(code); }
    catch {
      const ta = document.createElement('textarea');
      ta.value = code; document.body.appendChild(ta); ta.select();
      document.execCommand('copy'); document.body.removeChild(ta);
    }
    setCopied(true); setTimeout(() => setCopied(false), 1500);
  };
  return (
    <div style={{ position: 'relative', marginTop: 8, marginBottom: 8 }}>
      <SyntaxHighlighter style={oneDark} language={language} PreTag="div"
        customStyle={{ margin: 0, borderRadius: 6, fontSize: 12, paddingRight: 40 }}>
        {code}
      </SyntaxHighlighter>
      <button onClick={handleCopy} title="Copy code" style={{
        position: 'absolute', top: 6, right: 6,
        background: copied ? 'rgba(22,163,74,0.9)' : 'rgba(255,255,255,0.1)',
        border: 'none', borderRadius: 4, color: 'white',
        padding: '2px 8px', fontSize: 11, cursor: 'pointer',
        display: 'flex', alignItems: 'center', gap: 4, transition: 'background 0.2s', zIndex: 1,
      }}
        onMouseEnter={e => { if (!copied) (e.currentTarget.style.background = 'rgba(255,255,255,0.25)'); }}
        onMouseLeave={e => { if (!copied) (e.currentTarget.style.background = 'rgba(255,255,255,0.1)'); }}
      >
        <span className="material-symbols-outlined" style={{ fontSize: 14 }}>
          {copied ? 'check' : 'content_copy'}
        </span>
        {copied ? 'Copied!' : 'Copy'}
      </button>
    </div>
  );
};

// ── Thinking block ────────────────────────────────────────────────────────────
const ThinkingBlock: React.FC<{
  content: string;
  streaming: boolean;
  open: boolean;
  onToggle: () => void;
}> = ({ content, streaming, open, onToggle }) => (
  <div style={{ marginBottom: 6 }}>
    <button
      onClick={onToggle}
      style={{
        display: 'flex', alignItems: 'center', gap: 5,
        background: 'none', border: 'none', cursor: 'pointer',
        padding: '2px 0', color: '#7c3aed', fontSize: 11, fontWeight: 600,
      }}
    >
      <span className="material-symbols-outlined" style={{ fontSize: 13, color: '#7c3aed' }}>
        {streaming ? 'autorenew' : 'psychology'}
      </span>
      <span style={{ letterSpacing: '0.02em' }}>
        {streaming ? 'Thinking…' : 'Thought process'}
      </span>
      <span className="material-symbols-outlined" style={{ fontSize: 12, color: '#9ca3af', marginLeft: 2 }}>
        {open ? 'expand_less' : 'expand_more'}
      </span>
    </button>

    {open && (
      <div style={{
        marginTop: 4,
        padding: '8px 10px',
        background: '#faf5ff',
        border: '1px solid #e9d5ff',
        borderRadius: 8,
        fontSize: 11,
        color: '#6b21a8',
        lineHeight: 1.55,
        whiteSpace: 'pre-wrap',
        wordBreak: 'break-word',
        maxHeight: 280,
        overflowY: 'auto',
        fontFamily: 'ui-monospace, monospace',
      }}>
        {content || ' '}
        {streaming && (
          <span style={{
            display: 'inline-block', width: 6, height: 11,
            background: '#7c3aed', marginLeft: 2,
            animation: 'cordex-blink 0.9s step-end infinite',
            verticalAlign: 'text-bottom',
          }} />
        )}
      </div>
    )}
  </div>
);

// ── Message bubble ────────────────────────────────────────────────────────────
const MessageBubble: React.FC<{
  message: Message;
  isStreaming: boolean;
  isLast: boolean;
  onToggleThink: () => void;
}> = React.memo(({ message, isStreaming, isLast, onToggleThink }) => {
  if (message.role === 'user') {
    return (
      <div className="flex justify-end">
        <div className="max-w-[90%] px-3 py-2 rounded-xl text-sm bg-orange-500 text-white rounded-br-sm">
          <p className="whitespace-pre-wrap">{message.content}</p>
        </div>
      </div>
    );
  }

  const hasThinking = !!message.thinking;
  const isThinkingStreaming = isStreaming && isLast && hasThinking && !message.content;

  return (
    <div className="flex justify-start">
      <div className="max-w-[90%] px-3 py-2 rounded-xl text-sm bg-gray-100 text-gray-800 rounded-bl-sm overflow-x-auto">

        {/* Thinking block */}
        {hasThinking && (
          <ThinkingBlock
            content={message.thinking!}
            streaming={isThinkingStreaming}
            open={message.thinkOpen ?? false}
            onToggle={onToggleThink}
          />
        )}

        {/* Still thinking, no answer yet */}
        {isThinkingStreaming && !message.content && null}

        {/* Streaming answer — plain text for performance */}
        {isStreaming && isLast && message.content && (
          <>
            <pre className="whitespace-pre-wrap font-sans text-sm m-0">{message.content}</pre>
            <span className="inline-block w-2 h-4 bg-gray-400 animate-pulse ml-1" />
          </>
        )}

        {/* Completed answer — full markdown */}
        {(!isStreaming || !isLast) && message.content && (
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              p({ children }) { return <p style={{ marginBottom: '0.6em', marginTop: 0, lineHeight: 1.55 }}>{children}</p>; },
              ul({ children }) { return <ul style={{ paddingLeft: '1.2em', marginBottom: '0.6em', marginTop: 0 }}>{children}</ul>; },
              ol({ children }) { return <ol style={{ paddingLeft: '1.2em', marginBottom: '0.6em', marginTop: 0 }}>{children}</ol>; },
              li({ children }) { return <li style={{ marginBottom: '0.2em' }}>{children}</li>; },
              code({ className, children }) {
                const match = /language-(\w+)/.exec(className || '');
                const code = String(children).replace(/\n$/, '');
                return (!match && !className)
                  ? <code style={{ background: '#f1f5f9', padding: '1px 4px', borderRadius: 3, fontSize: '0.9em' }}>{children}</code>
                  : <CodeBlock language={match?.[1] ?? 'text'} code={code} />;
              },
            }}
          >
            {message.content}
          </ReactMarkdown>
        )}

        {/* Empty assistant message while loading (no thinking yet) */}
        {isStreaming && isLast && !message.content && !hasThinking && (
          <span className="inline-block w-2 h-4 bg-gray-400 animate-pulse ml-1" />
        )}
      </div>
    </div>
  );
});

// ── Main ChatPanel ────────────────────────────────────────────────────────────
export const ChatPanel: React.FC = () => {
  const { state } = useAppState();
  const [messages, setMessages]   = useState<Message[]>([]);
  const [input, setInput]         = useState('');
  const [loading, setLoading]     = useState(false);
  const abortRef    = useRef<() => void>(() => {});
  const scrollRef   = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [selectionInfo, setSelectionInfo] = useState<{ hasSelection: boolean; preview: string; lineCount: number }>({ hasSelection: false, preview: '', lineCount: 0 });

  const [mentionQuery, setMentionQuery] = useState('');
  const [mentionIndex, setMentionIndex] = useState(0);
  const [showMentions, setShowMentions] = useState(false);

  useEffect(() => {
    const id = setInterval(() => {
      const info = (window as any).__cordexGetSelectionInfo?.();
      if (info) setSelectionInfo(info);
    }, 100);
    return () => clearInterval(id);
  }, []);

  const allFiles = useRef<string[]>([]);
  useEffect(() => { allFiles.current = flattenFileTree(state.fileTree || []).sort(); }, [state.fileTree]);

  const filteredFiles = React.useMemo(() => {
    if (!mentionQuery) return [];
    const q = mentionQuery.toLowerCase();
    return allFiles.current.filter(f => f.toLowerCase().includes(q)).slice(0, 10);
  }, [mentionQuery]);

  const scrollToBottom = useCallback(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, []);
  useEffect(() => { scrollToBottom(); }, [messages, loading]);

  // Streaming buffers — separate for thinking and content
  const thinkBuf = useRef<{ timer: ReturnType<typeof setTimeout> | null; chunks: string[] }>({ timer: null, chunks: [] });
  const contentBuf = useRef<{ timer: ReturnType<typeof setTimeout> | null; chunks: string[] }>({ timer: null, chunks: [] });

  const flushThink = useCallback(() => {
    const text = thinkBuf.current.chunks.join('');
    if (!text) return;
    setMessages(prev => prev.map((m, i) =>
      i === prev.length - 1 && m.role === 'assistant'
        ? { ...m, thinking: (m.thinking ?? '') + text, thinkOpen: m.thinkOpen ?? true }
        : m
    ));
    thinkBuf.current.chunks = [];
    thinkBuf.current.timer = null;
  }, []);

  const flushContent = useCallback(() => {
    const text = contentBuf.current.chunks.join('');
    if (!text) return;
    setMessages(prev => prev.map((m, i) =>
      i === prev.length - 1 && m.role === 'assistant'
        ? { ...m, content: m.content + text }
        : m
    ));
    contentBuf.current.chunks = [];
    contentBuf.current.timer = null;
  }, []);

  const send = async () => {
    const text = input.trim();
    console.log('messages in send:', messages);
    if (!text || loading) return;
    abortRef.current?.();

    const userMsg: Message = { role: 'user', content: text };
    setMessages(prev => [...prev, userMsg, { role: 'assistant', content: '', thinking: undefined, thinkOpen: false }]);
    setInput('');
    setLoading(true);

    thinkBuf.current = { timer: null, chunks: [] };
    contentBuf.current = { timer: null, chunks: [] };

    const currentFile = state.tabs.find(t => t.id === state.activeTabId)?.path;
    const selection   = (window as any).__cordexGetSelection?.();
    const context     = { projectRoot: state.projectRoot, currentFile, selection: selection || undefined };

    const cleanup = Cordex?.ai?.chatStream(
      { messages: [...messages, userMsg], context },
      {
        onThinking: (chunk: string) => {
          thinkBuf.current.chunks.push(chunk);
          if (!thinkBuf.current.timer) {
            thinkBuf.current.timer = setTimeout(flushThink, 40);
          }
        },
        onChunk: (chunk: string) => {
          contentBuf.current.chunks.push(chunk);
          if (!contentBuf.current.timer) {
            contentBuf.current.timer = setTimeout(flushContent, 40);
          }
        },
        onDone: () => {
          if (thinkBuf.current.timer)   { clearTimeout(thinkBuf.current.timer);   flushThink(); }
          if (contentBuf.current.timer) { clearTimeout(contentBuf.current.timer); flushContent(); }
          setLoading(false);
        },
        onError: (err: string) => {
          if (thinkBuf.current.timer)   { clearTimeout(thinkBuf.current.timer);   flushThink(); }
          if (contentBuf.current.timer) { clearTimeout(contentBuf.current.timer); flushContent(); }
          setMessages(prev => prev.map((m, i) =>
            i === prev.length - 1 && m.role === 'assistant'
              ? { ...m, content: m.content + `\n[Error] ${err}` }
              : m
          ));
          setLoading(false);
        },
      }
    );

    abortRef.current = () => {
      cleanup?.();
      if (thinkBuf.current.timer)   clearTimeout(thinkBuf.current.timer);
      if (contentBuf.current.timer) clearTimeout(contentBuf.current.timer);
      setLoading(false);
    };
  };

  // Toggle thinking block for a given message index
  const toggleThink = useCallback((idx: number) => {
    setMessages(prev => prev.map((m, i) => i === idx ? { ...m, thinkOpen: !m.thinkOpen } : m));
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    setInput(value);
    const cursorPos = e.target.selectionStart ?? 0;
    const atMatch = value.slice(0, cursorPos).match(/@(\S*)$/);
    if (atMatch) { setMentionQuery(atMatch[1]); setShowMentions(true); setMentionIndex(0); }
    else setShowMentions(false);
  };

  const insertMention = (filePath: string) => {
    const ta = textareaRef.current;
    if (!ta) return;
    const cur = ta.selectionStart ?? 0;
    const before = input.slice(0, cur).replace(/@\S*$/, `@${filePath} `);
    setInput(before + input.slice(cur));
    setShowMentions(false);
    setTimeout(() => { ta.selectionStart = ta.selectionEnd = before.length + 1; ta.focus(); }, 0);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (showMentions && filteredFiles.length > 0) {
      if (e.key === 'ArrowDown')  { e.preventDefault(); setMentionIndex(i => (i + 1) % filteredFiles.length); return; }
      if (e.key === 'ArrowUp')    { e.preventDefault(); setMentionIndex(i => (i - 1 + filteredFiles.length) % filteredFiles.length); return; }
      if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); insertMention(filteredFiles[mentionIndex]); return; }
      if (e.key === 'Escape')     { setShowMentions(false); return; }
    }
    if (e.key === 'Enter' && !e.shiftKey && !showMentions) { e.preventDefault(); send(); }
  };

  return (
    <div className="flex flex-col h-full bg-white">
      <style>{`
        @keyframes cordex-blink { 0%,100%{opacity:1} 50%{opacity:0} }
        @keyframes cordex-spin  { to{transform:rotate(360deg)} }
        .cordex-think-spin { animation: cordex-spin 1.2s linear infinite; }
      `}</style>

      {selectionInfo.hasSelection && (
        <div className="px-4 py-2 bg-green-50 border-b border-green-200 flex items-center gap-2 text-xs">
          <span className="material-symbols-outlined text-green-600 text-[14px]">check_circle</span>
          <span className="text-green-700 font-medium">
            Selection active: {selectionInfo.lineCount} {selectionInfo.lineCount === 1 ? 'line' : 'lines'} • {selectionInfo.preview}
          </span>
        </div>
      )}

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-3">
        {messages.map((msg, i) => (
          <MessageBubble
            key={i}
            message={msg}
            isStreaming={loading}
            isLast={i === messages.length - 1}
            onToggleThink={() => toggleThink(i)}
          />
        ))}
      </div>

      <div className="relative p-3 border-t border-gray-200 space-y-2">
        <textarea
          ref={textareaRef}
          value={input}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          placeholder="Ask about your code… use @ to mention files"
          className="w-full border border-gray-200 rounded-lg p-2 text-sm resize-none focus:outline-none focus:border-orange-400"
          rows={2}
          disabled={loading}
        />
        {showMentions && filteredFiles.length > 0 && (
          <div className="absolute bottom-full mb-1 left-3 right-3 bg-white border border-gray-200 rounded-lg shadow-lg max-h-40 overflow-y-auto z-50">
            {filteredFiles.map((file, idx) => (
              <div key={file}
                className={`px-3 py-1 text-sm cursor-pointer flex items-center gap-2 ${idx === mentionIndex ? 'bg-orange-50 text-orange-600' : 'hover:bg-gray-50'}`}
                onClick={() => insertMention(file)}
              >
                <span className="material-symbols-outlined text-[14px]">description</span>
                {file}
              </div>
            ))}
          </div>
        )}
        <div className="flex items-center justify-between">
          <button onClick={() => { abortRef.current?.(); setMessages([]); }} disabled={loading}
            className="text-xs text-gray-400 hover:text-gray-600 disabled:opacity-30">
            Clear
          </button>
          <div className="flex gap-2">
            {loading && (
              <button onClick={() => abortRef.current?.()}
                className="flex items-center gap-1 px-3 py-1 text-xs font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-full">
                <span className="material-symbols-outlined text-[14px]">stop</span> Stop
              </button>
            )}
            <button onClick={send} disabled={!input.trim() || loading}
              className="flex items-center gap-1 px-3 py-1 text-xs font-medium text-white bg-orange-500 hover:bg-orange-600 disabled:opacity-40 rounded-full">
              <span className="material-symbols-outlined text-[14px]">send</span> Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};